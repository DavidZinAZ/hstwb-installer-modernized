#ifdef FLASH_SPI

#ifdef _KERNEL
#ifdef DEBUG_FLASH
#define USE_SERIAL_OUTPUT
#endif
#include "port.h"
#endif

#include <exec/execbase.h>
#include <proto/exec.h>
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include "flash.h"
#include "spi.h"
#include "nibble_word.h"

// This is a stand-in until I get SysBase properly
extern struct ExecBase *SysBase;

/* Use mirrored addresses for writes to work around 68030 write-allocation bug.
 * The MMU must be configured to make the write-mirror non-cacheable.
 * For now however, we disable write-allocation instead of using different
 * addresses.
 */
#define SPI_PORT_WRITE_HOLD_OFFS 0x7FFFC0
#define SPI_PORT_WRITE_END_OFFS  0x7FFFD0
#define SPI_PORT_READ_HOLD_OFFS  0x7FFFE0
#define SPI_PORT_READ_END_OFFS   0x7FFFF0

/* MMIO access helpers using shared nibble_word functions */
static inline void mmio_write_hold(uint32_t base, uint8_t v)
{
    volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)(base + SPI_PORT_WRITE_HOLD_OFFS);
    *p = pack_nibble_word(v);
}
static inline void mmio_write_end(uint32_t base, uint8_t v)
{
    volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)(base + SPI_PORT_WRITE_END_OFFS);
    *p = pack_nibble_word(v);
}
static inline uint8_t mmio_read_hold(uint32_t base)
{
    volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)(base + SPI_PORT_READ_HOLD_OFFS);
    uint32_t w = *p;
    return unpack_nibble_word(w);
}
static inline uint8_t mmio_read_end(uint32_t base)
{
    volatile uint32_t *p = (volatile uint32_t *)(uintptr_t)(base + SPI_PORT_READ_END_OFFS);
    uint32_t w = *p;
    return unpack_nibble_word(w);
}

/* ===== SPI commands / constants ===== */
enum {
    SPI_CMD_WREN    = 0x06,
    SPI_CMD_RDSR1   = 0x05,
    SPI_CMD_WRSR    = 0x01,
    SPI_CMD_RDSR2   = 0x35,
    SPI_CMD_RDID    = 0x9F,
    SPI_CMD_READ    = 0x03,
    SPI_CMD_PP      = 0x02,
    SPI_CMD_SE_4K   = 0x20, // New
    SPI_CMD_BE_32K  = 0x52, // New
    SPI_CMD_BE_64K  = 0xD8,
    SPI_CMD_RUID    = 0x4B,
};

/* ===== low-level bytewise helpers ===== */
static inline void spi_tx_hold(uint32_t base, uint8_t v) { mmio_write_hold(base, v); }
static inline void spi_tx_end (uint32_t base, uint8_t v) {
    mmio_write_end (base, v);
}
static inline uint8_t spi_rx_hold(uint32_t base) {
    return mmio_read_hold(base);
}
static inline uint8_t spi_rx_end (uint32_t base) {
    return mmio_read_end (base);
}

/* ===== status / waits ===== */
static void spi_write_enable(uint32_t base)
{
    spi_tx_end(base, SPI_CMD_WREN);
}
uint8_t spi_read_sr1(uint32_t base)
{
    spi_tx_hold(base, SPI_CMD_RDSR1);
    return spi_rx_end(base);
}
uint8_t spi_read_sr2(uint32_t base)
{
    spi_tx_hold(base, SPI_CMD_RDSR2);
    return spi_rx_end(base);
}
static bool spi_wait_wip_clear(uint32_t base, uint32_t max_iters)
{
    for (uint32_t i = 0; i < max_iters; ++i) {
        if ((spi_read_sr1(base) & SR1_WIP) == 0) {
            return true;
        }
    }
    flash_printf("SPI: timeout waiting for WIP clear (SR1=%02X)\n",
                        spi_read_sr1(base));
    return false;
}
static bool spi_wait_wel_set(uint32_t base, uint32_t max_iters)
{
    while (max_iters--) {
        if (spi_read_sr1(base) & SR1_WEL) {
            return true;
        }
    }
    return false;
}

static bool spi_write_status(uint32_t base, uint8_t sr1, uint8_t sr2)
{
    spi_write_enable(base);
    if (!spi_wait_wel_set(base, 1000)) {
        flash_printf("ERROR: WEL not set before status write\n");
        return false;
    }
    spi_tx_hold(base, SPI_CMD_WRSR);
    spi_tx_hold(base, sr1);
    spi_tx_end(base, sr2);
    if (!spi_wait_wip_clear(base, 100000)) {
        flash_printf("ERROR: status register write timed out\n");
        return false;
    }
    return true;
}

bool spi_clear_block_protect(uint32_t base)
{
    uint8_t sr1 = spi_read_sr1(base);
    uint8_t sr2 = spi_read_sr2(base);
    if ((sr1 & SR1_BP_MASK) == 0) {
        return true;
    }
    uint8_t new_sr1 = sr1 & (uint8_t)~SR1_BP_MASK;
    flash_printf("SPI flash reports block protection (SR1=%02X SR2=%02X); clearing BP bits...\n",
                        sr1, sr2);
    if (!spi_write_status(base, new_sr1, sr2)) {
        flash_printf("ERROR: failed to clear block protection bits\n");
        return false;
    }
    uint8_t verify1 = spi_read_sr1(base);
    uint8_t verify2 = spi_read_sr2(base);
    if (verify1 & SR1_BP_MASK) {
	(void)verify2;
        flash_printf("ERROR: block protection bits still set (SR1=%02X SR2=%02X). Check WP# pin.\n",
                            verify1, verify2);
        return false;
    }
    return true;
}

/* ===== single ops ===== */
void spi_read_id(uint32_t base, uint8_t *mfg, uint8_t *type, uint8_t *cap)
{
    spi_tx_hold(base, SPI_CMD_RDID);
    if (mfg)  *mfg  = spi_rx_hold(base);
    if (type) *type = spi_rx_hold(base);
    if (cap)  *cap  = spi_rx_end(base);
}

void spi_read_unique_id(uint32_t base, uint8_t id[8])
{
    int i;
    spi_tx_hold(base, SPI_CMD_RUID);
    for (i = 0; i < 4; i++)
        spi_tx_hold(base, 0x00);       /* 4 dummy bytes */
    for (i = 0; i < 7; i++)
        id[i] = spi_rx_hold(base);
    id[7] = spi_rx_end(base);
}

static bool spi_block_erase(uint32_t base, uint32_t baddr, uint8_t erase_cmd)
{
    spi_write_enable(base);
    if (!spi_wait_wel_set(base, 1000)) {
        flash_printf("ERROR: WEL not set before erase at 0x%08lX\n",
                            (unsigned long)baddr);
        return false;
    }
    spi_tx_hold(base, erase_cmd);
    spi_tx_hold(base, (baddr >> 16) & 0xFF);
    spi_tx_hold(base, (baddr >> 8)  & 0xFF);
    spi_tx_end (base,  baddr        & 0xFF);
    return spi_wait_wip_clear(base, 2000000);
}

bool spi_sector_erase_4k(uint32_t base, uint32_t baddr) {
    return spi_block_erase(base, baddr, SPI_CMD_SE_4K);
}

static bool spi_page_program(uint32_t base, uint32_t addr, const uint8_t *data, size_t len)
{
    if (!len || len > SPI_PAGE_SIZE) return false;
    spi_write_enable(base);
    if (!spi_wait_wel_set(base, 1000)) {
        flash_printf("ERROR: WEL not set before program at 0x%08lX\n",
                            (unsigned long)addr);
        return false;
    }
    spi_tx_hold(base, SPI_CMD_PP);
    spi_tx_hold(base, (addr >> 16) & 0xFF);
    spi_tx_hold(base, (addr >> 8)  & 0xFF);
    spi_tx_hold(base,  addr        & 0xFF);
    for (size_t i=0; i+1<len; ++i) spi_tx_hold(base, data[i]);
    spi_tx_end(base, data[len-1]);
    return spi_wait_wip_clear(base, 100000);
}

/* ===== streaming helpers ===== */
bool spi_read_buf(uint32_t base, uint32_t addr, uint8_t *out, size_t len)
{
    if (!len) return true;
    spi_tx_hold(base, SPI_CMD_READ);
    spi_tx_hold(base, (addr >> 16) & 0xFF);
    spi_tx_hold(base, (addr >> 8)  & 0xFF);
    spi_tx_hold(base,  addr        & 0xFF);
    for (size_t i=0; i+1<len; ++i) out[i] = spi_rx_hold(base);
    out[len-1] = spi_rx_end(base);
    return true;
}

bool spi_write_buf_pagewise(uint32_t base, uint32_t addr, const uint8_t *in, size_t len, void (*progress)(size_t done, size_t total))
{
    size_t done = 0;
    size_t total = len;
    while (len) {
        uint32_t page_off  = addr & (SPI_PAGE_SIZE-1);
        uint32_t page_room = SPI_PAGE_SIZE - page_off;
        size_t chunk = len < page_room ? len : page_room;
        if (!spi_page_program(base, addr, in, chunk)) return false;
        addr += chunk; in += chunk; len -= chunk; done += chunk;
        if (progress) progress(done, total);
    }
    return true;
}

bool spi_erase_range_blocks(uint32_t base, uint32_t addr, size_t len,
                            void (*progress)(size_t done, size_t total))
{
    if (len & (SPI_BLOCK_SIZE - 1))
        flash_printf("WARNING: erase size 0x%lX is not a multiple of 64KB\n",
                            (unsigned long)len);

    uint32_t start = (addr / SPI_BLOCK_SIZE) * SPI_BLOCK_SIZE;
    uint32_t end   = ((addr + (uint32_t)len - 1) / SPI_BLOCK_SIZE) * SPI_BLOCK_SIZE;
    size_t total = (end - start) / SPI_BLOCK_SIZE + 1, k = 0;

    for (uint32_t b = start; b <= end; b += SPI_BLOCK_SIZE, ++k) {
        if (progress) progress(k, total);
        if (!spi_block_erase(base, b, SPI_CMD_BE_64K)) return false;
    }
    if (progress) progress(total, total);

    return true;
}

bool spi_erase_chip(uint32_t base, ULONG flashSize) {
    return spi_erase_range_blocks(base, 0, flashSize, NULL);
}

bool spi_erase_bank(uint32_t base, ULONG bankSize) {
    return spi_erase_range_blocks(base, 0, bankSize, NULL);
}

/* ===== Abstraction layer implementation ===== */
/* These functions provide the interface expected by flash.c */

static uint32_t spi_base_address = 0;
static ULONG spi_flash_size = 0;

/**
 * spi_flash_init
 *
 * @brief Initialize and detect SPI flash
 * @param manuf Pointer to store manufacturer ID
 * @param devid Pointer to store device ID (capacity)
 * @param base Base address of the board
 * @param size Pointer to store flash size in bytes
 * @param sectorSize Pointer to store sector/block size (64KB for SPI)
 * @return true if SPI flash detected and initialized
 */
bool spi_flash_init(UBYTE *manuf, UBYTE *devid, volatile UBYTE *base, ULONG *size, ULONG *sectorSize)
{
    uint8_t mfg = 0, type = 0, cap = 0;
    spi_base_address = (uint32_t)(uintptr_t)base;

    // Read JEDEC ID
    spi_read_id(spi_base_address, &mfg, &type, &cap);

    // Check if it's a valid SPI flash (manufacturer should not be 0xFF or 0x00)
    if (mfg == 0xFF || mfg == 0x00 || mfg == 0x9F) {
        spi_base_address = 0;
        return false;
    }

    // Calculate flash size from capacity byte
    // Capacity byte is log2(size_in_bytes)
    // For W25Q64: cap=0x17 means 2^23 bytes = 8MB
    spi_flash_size = 1UL << cap;

    // Return values
    if (manuf) *manuf = mfg;
    if (devid) *devid = cap;  // Return capacity as device ID
    if (size) *size = spi_flash_size;
    if (sectorSize) *sectorSize = SPI_BLOCK_SIZE;  // 64KB blocks

    // Clear block protection
    if (!spi_clear_block_protect(spi_base_address)) {
        spi_base_address = 0;
        return false;
    }

    // Print flash info
    const char *vendor = "Unknown";
    const char *device = "Unknown";

    uint16_t did;
    did = (type << 8) | cap;

    switch (mfg) {
        case 0xEF:
            vendor = "Winbond";
	    switch (did) {
                case 0x3011: device = "W25X10"; break;
                case 0x3012: device = "W25X20"; break;
                case 0x3013: device = "W25X40"; break;
                case 0x3014: device = "W25X80"; break;
                case 0x4013: device = "W25Q40"; break;
                case 0x4017: device = "W25Q64"; break;
                case 0x4018: device = "W25Q128"; break;
            }
            break;
        case 0xC2:
            vendor = "Macronix";
	    switch (did) {
                case 0x2017: device = "MX25L6405"; break;
            }
            break;
    }

    (void)vendor; (void)device;
    flash_printf("Flash part: %s %s (%lu KB)\n", vendor, device,
                        (unsigned long)(spi_flash_size / 1024));

    return true;
}

/**
 * spi_flash_readByte
 *
 * @brief Read a single byte from SPI flash
 * @param address Byte address to read from
 * @return The byte read
 */
UBYTE spi_flash_readByte(ULONG address)
{
    uint8_t byte = 0xFF;
    if (!spi_read_buf(spi_base_address, address, &byte, 1))
        return 0xFF;
    return byte;
}

/**
 * spi_flash_readBuf
 *
 * @brief Bulk read from SPI flash
 * @param address Starting byte address
 * @param buf Buffer to read into
 * @param len Number of bytes to read
 * @return true on success
 */
bool spi_flash_readBuf(ULONG address, UBYTE *buf, ULONG len)
{
    return spi_read_buf(spi_base_address, address, buf, len);
}

/**
 * spi_flash_writeByte
 *
 * @brief Write a single byte to SPI flash
 * @param address Byte address to write to
 * @param data Byte to write
 */
void spi_flash_writeByte(ULONG address, UBYTE data)
{
    if (!spi_write_buf_pagewise(spi_base_address, address, &data, 1, NULL)) {
        flash_printf("Write failed at address 0x%08lX\n",
                     (unsigned long)address);
    }
}

/**
 * spi_flash_erase_sector
 *
 * @brief Erase a flash region using the smallest erase granularity that fits.
 *        Uses 4KB sector erase when size and alignment permit, otherwise 64KB block erase.
 * @param address Starting address
 * @param sectorSize Size of region to erase
 * @return true on success, false on failure
 */
bool spi_flash_erase_sector_with_progress(ULONG address, ULONG sectorSize,
                                          void (*progress)(void *ctx,
                                                           ULONG done,
                                                           ULONG total),
                                          void *progressCtx)
{
    ULONG start = address;
    BOOL smoothProgress = (progress != NULL && sectorSize <= SPI_BLOCK_SIZE);

    if (sectorSize & (SPI_SECTOR_SIZE_4K - 1))
        flash_printf("WARNING: erase size 0x%lX is not a multiple of 4KB\n",
                            (unsigned long)sectorSize);

    ULONG end = address + sectorSize;

    if (progress)
        progress(progressCtx, 0, sectorSize);

    while (address < end) {
        ULONG remaining = end - address;
        ULONG erasedSize;

        if (!smoothProgress &&
            (address & (SPI_BLOCK_SIZE - 1)) == 0 &&
            remaining >= SPI_BLOCK_SIZE) {
            if (!spi_block_erase(spi_base_address, address, SPI_CMD_BE_64K))
                return false;
            erasedSize = SPI_BLOCK_SIZE;
        } else {
            if (!spi_sector_erase_4k(spi_base_address, address))
                return false;
            erasedSize = SPI_SECTOR_SIZE_4K;
        }

        address += erasedSize;
        if (progress)
            progress(progressCtx, address - start, sectorSize);
    }

    return true;
}

bool spi_flash_erase_sector(ULONG address, ULONG sectorSize)
{
    return spi_flash_erase_sector_with_progress(address, sectorSize, NULL, NULL);
}

/**
 * spi_flash_erase_chip
 *
 * @brief Erase the entire SPI flash chip
 * @return true if erase and verification successful, false otherwise
 */
bool spi_flash_erase_chip(void)
{
    return spi_erase_range_blocks(spi_base_address, 0, spi_flash_size, NULL);
}

/**
 * spi_flash_cleanup
 *
 * @brief Cleanup SPI flash
 */
void spi_flash_cleanup(void)
{
}

#endif /* FLASH_SPI */
