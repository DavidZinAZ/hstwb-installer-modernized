// SPDX-License-Identifier: GPL-2.0-only
/* This file is part of a4092flash
 * Copyright (C) 2023 Matthew Harlum <matt@harlum.net>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 2.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 */

#ifndef MAIN_H
#define MAIN_H

#include <stdbool.h>
#include <stdint.h>
#include <exec/lists.h>
#include <exec/ports.h>

#define STR(s) #s      /* Turn s into a string literal without expanding macro definitions (however, \
                          if invoked from a macro, macro arguments are expanded). */
#define XSTR(s) STR(s) /* Turn s into a string literal after macro-expanding it. */

#define VERSION_STRING "$VER: a4092flash " XSTR(DEVICE_VERSION) "." XSTR(DEVICE_REVISION) " (" XSTR(BUILD_DATE) ") " XSTR(GIT_REF)
#define VERSION "a4092flash " XSTR(DEVICE_VERSION) "." XSTR(DEVICE_REVISION) " (" XSTR(BUILD_DATE) ") " XSTR(GIT_REF)

// NDK 1.3 includes lacks these, so define them here
#ifdef __KICK13__
void ColdReboot(void);
struct DosList *LockDosList(ULONG);
struct DosList *NextDosEntry(struct DosList *, ULONG);
void *UnLockDosList(ULONG);
#endif

#ifdef SHARED_REGISTERS
bool inhibitDosDevs(bool inhibit);
#endif

struct scsiBoard {
  struct ConfigDev *cd;
  volatile UBYTE *flashbase;
};

struct dosDev {
  struct MinNode mn;
  struct MsgPort *handler;
  char *name;
};

struct nvramParams {
  bool need_init;
  bool need_read;
  bool need_write;
  bool read_osflags;
  bool read_switchflags;
  uint8_t write_osflags;
  uint8_t write_switchflags;
  bool write_osflags_set;
  bool write_switchflags_set;
};

enum flashWritePhase {
  FLASH_WRITE_PHASE_PROGRAM = 0,
  FLASH_WRITE_PHASE_VERIFY
};

typedef void (*flashWriteProgressFn)(void *ctx, enum flashWritePhase phase,
                                     ULONG done, ULONG total);

ULONG getFileSize(char *);
BOOL readFileToBuf(char *, void *);
BOOL writeFlashToFile(char *filename, ULONG romSize);
BOOL writeBufToFlash(struct scsiBoard *board, UBYTE *source, volatile UBYTE *dest, ULONG size);
BOOL writeBufToFlashWithProgress(struct scsiBoard *board, UBYTE *source,
                                 volatile UBYTE *dest, ULONG size,
                                 flashWriteProgressFn progressFn,
                                 void *progressCtx);

#endif
