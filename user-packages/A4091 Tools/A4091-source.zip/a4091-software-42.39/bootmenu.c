//
// Copyright 2022-2025 Stefan Reinauer & Chris Hooper
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice,
//    this list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
//

#ifdef DEBUG_BOOTMENU
#define USE_SERIAL_OUTPUT
#endif

#include "port.h"
#include <stdio.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <exec/execbase.h>
#include <exec/types.h>
#include <exec/libraries.h>
#include <exec/resident.h>

#include <proto/exec.h>
#include <intuition/intuition.h>
#include <intuition/screens.h>
#include <intuition/gadgetclass.h>
#include <libraries/gadtools.h>

#include <graphics/text.h>
#include <graphics/displayinfo.h>
#include <graphics/videocontrol.h>
#include <graphics/rastport.h>
#include <graphics/gfxmacros.h>
#include <devices/inputevent.h>

#include <graphics/gfxbase.h>
#include <clib/intuition_protos.h>
#include <clib/graphics_protos.h>
#include <clib/gadtools_protos.h>
#include "bootmenu.h"
#include "device.h"
#include "scsipiconf.h"
#include "siopreg.h"
#include "siopvar.h"
#include "attach.h"
#include "scsimsg.h"
#include "battmem.h"
#include "amigahw.h"
#include "ndkcompat.h"
#include "version.h"
#include "mounter.h" // for Port/IOReq wrappers
#include "a4091.h"

#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
#include "util/a4092flash/mfg_flash.h"
#include "util/a4092flash/flash.h"
#endif

#if defined(FLASH_PARALLEL) || defined(FLASH_SPI) || defined(OEM_KICKMODULE)
#include "util/a4092flash/oem_flash.h"
extern void zx0_decompress(const void *src, void *dst);
static bool oem_bundle_valid = false;
static int oem_selected_slot = -1;
static struct oem_header oem_hdr;
static UBYTE *oem_bitmap_data = NULL;
static ULONG oem_bitmap_size = 0;
static struct BitMap oem_bitmap;
static WORD oem_draw_x = 0;
static WORD oem_draw_y = 0;
#ifdef OEM_KICKMODULE
static const UBYTE *oem_blob_base = NULL; /* points to OEM bundle in ROM */
#endif
#endif

#if defined(DRIVER_A4091)
#define BOOTMENU_NAME "A4091"
#elif defined(DRIVER_A4092)
#define BOOTMENU_NAME "A4092"
#elif defined(DRIVER_A4770)
#define BOOTMENU_NAME "A4770 Cheetah"
#elif defined(DRIVER_A4000T)
#define BOOTMENU_NAME "NCR53C710"
#elif defined(DRIVER_A4000T770)
#define BOOTMENU_NAME "A4000D+"
#endif

struct GfxBase *GfxBase;
struct Library *GadToolsBase;
struct Library *IntuitionBase;
static struct Screen *screen;
static struct Window *window;
static APTR visualInfo;
static struct Gadget *gadgets;
static struct Gadget *DisplayTypeGad;
static struct Gadget *LastAdded;
static struct NewGadget *NewGadget;
static int current_page = 0; // 0=main, 1=disks, 2=dipswitch, 3=about, 4=debug, 5=mfg

#define DISKS_BACK_ID      1
#define DIPSWITCH_BACK_ID  2
#define ABOUT_BACK_ID      3
#define DEBUG_BACK_ID      4
#define MAIN_ABOUT_ID      5
#define MAIN_DISKS_ID      6
#define MAIN_DIPSWITCH_ID  7
#define MAIN_DEBUG_ID      8
#define MAIN_BOOT_ID       9
#define DEBUG_CDROM_BOOT_ID  10
#define DEBUG_IGNORE_LAST_ID 11
#define DEBUG_BOGUS_ID       12
#define DEBUG_QUICK_INT_ID   13
#define DEBUG_ALLOW_DISC_ID  14
#define MFG_BACK_ID          15

#define ARRAY_LENGTH(array) (sizeof((array))/sizeof((array)[0]))
#define WIDTH  640

static const struct TextAttr font_attr =
{
    "topaz.font",
     8,
     FS_NORMAL,
     FPF_ROMFONT
};

static bool open_bootmenu_screen(UWORD depth)
{
    UWORD pens = 0xffff;
    struct TagItem taglist[2];
    ULONG monitor_id;

    if (GfxBase->DisplayFlags & NTSC)
        monitor_id = NTSC_MONITOR_ID | HIRES_KEY;
    else
        monitor_id = PAL_MONITOR_ID | HIRES_KEY;

    taglist[0].ti_Tag  = VTAG_BORDERSPRITE_SET;
    taglist[0].ti_Data = TRUE;
    taglist[1].ti_Tag  = TAG_DONE;

    screen = OpenScreenTags(NULL,
        SA_Depth,        depth,
        SA_Font,         &font_attr,
        SA_Type,         CUSTOMSCREEN,
        SA_DisplayID,    monitor_id,
        SA_Interleaved,  TRUE,
        SA_Draggable,    FALSE,
        SA_Quiet,        TRUE,
        SA_Pens,         &pens,
        SA_VideoControl, taglist,
        TAG_DONE);
    if (!screen)
        return false;

    window = OpenWindowTags(NULL,
        WA_IDCMP,         (IDCMP_RAWKEY | IDCMP_VANILLAKEY | IDCMP_MOUSEBUTTONS | BUTTONIDCMP | LISTVIEWIDCMP | MXIDCMP),
        WA_CustomScreen,  screen,
        WA_Flags,         (WFLG_NOCAREREFRESH | WFLG_BORDERLESS | WFLG_ACTIVATE | WFLG_RMBTRAP),
        TAG_DONE);
    if (!window) {
        CloseScreen(screen);
        screen = NULL;
        return false;
    }

    visualInfo = GetVisualInfoA(screen,NULL);
    if (!visualInfo) {
        CloseWindow(window);
        window = NULL;
        CloseScreen(screen);
        screen = NULL;
        return false;
    }
    return true;
}

#if defined(FLASH_PARALLEL) || defined(FLASH_SPI) || defined(OEM_KICKMODULE)
static uint32_t oem_checksum(const struct oem_header *h)
{
    const uint32_t *words = (const uint32_t *)h;
    uint32_t xor = 0;

    for (size_t i = 0; i < (offsetof(struct oem_header, checksum) / 4); i++)
        xor ^= words[i];
    return xor;
}

static bool oem_variant_present(int slot)
{
    return slot >= 0 &&
           slot < OEM_VARIANT_SLOTS &&
           oem_hdr.variant[slot].compressed_size != 0;
}

static UWORD oem_variant_depth(int slot)
{
    return (UWORD)OEM_VARIANT_DEPTH(slot);
}

static const struct oem_variant *oem_selected_variant(void)
{
    return oem_variant_present(oem_selected_slot) ? &oem_hdr.variant[oem_selected_slot] : NULL;
}

static bool oem_validate_bundle(const struct oem_header *h, ULONG available_size)
{
    int present = 0;

    if (!h || available_size < sizeof(*h) || !OEM_IS_VALID(h))
        return false;
    if (available_size < h->total_size)
        return false;
    if (oem_checksum(h) != h->checksum)
        return false;

    for (int slot = 0; slot < OEM_VARIANT_SLOTS; slot++) {
        const struct oem_variant *variant = &h->variant[slot];
        UWORD depth = oem_variant_depth(slot);

        if (variant->compressed_size == 0) {
            if (variant->width != 0 ||
                variant->height != 0 ||
                variant->uncompressed_size != 0 ||
                variant->data_offset != 0)
                return false;
            continue;
        }

        present++;

        if (variant->width == 0 || variant->height == 0)
            return false;
        if (variant->data_offset < sizeof(*h))
            return false;
        if (variant->data_offset > h->total_size)
            return false;
        if (variant->compressed_size > (h->total_size - variant->data_offset))
            return false;
        if (variant->uncompressed_size != oem_expected_uncompressed_size(variant, depth))
            return false;
    }

    return present > 0 && present == h->variant_count;
}

static WORD oem_resolve_coord(UWORD value, WORD span, UWORD size)
{
    if (value == OEM_COORD_CENTER)
        return (span - (WORD)size) / 2;
    return (WORD)value;
}

static void oem_free_cache(void)
{
    if (oem_bitmap_data) {
        FreeMem(oem_bitmap_data, oem_bitmap_size);
        oem_bitmap_data = NULL;
    }
    oem_bitmap_size = 0;
    memset(&oem_bitmap, 0, sizeof(oem_bitmap));
    oem_draw_x = 0;
    oem_draw_y = 0;
}

static void probe_oem_bundle(void)
{
    const struct oem_header *h = NULL;
    ULONG available_size = 0;

    oem_bundle_valid = false;
    oem_selected_slot = -1;
    oem_free_cache();
#ifdef OEM_KICKMODULE
    oem_blob_base = NULL;
    {
        struct Resident *res = FindResident("scsi_assets.resource");
        if (res && res->rt_Init) {
            h = (const struct oem_header *)res->rt_Init;
            available_size = (ULONG)((const UBYTE *)res->rt_EndSkip -
                                     (const UBYTE *)res->rt_Init);
        }
    }
#endif
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
    if (!h && flash_get_type() != FLASH_TYPE_NONE) {
        if (flash_readBuf(OEM_FLASH_OFFSET, (UBYTE *)&oem_hdr, sizeof(oem_hdr))) {
            h = &oem_hdr;
            available_size = OEM_FLASH_SIZE;
        }
    }
#endif
    if (h && oem_validate_bundle(h, available_size)) {
        if (h != &oem_hdr)
            oem_hdr = *h;
#ifdef OEM_KICKMODULE
        if (h != &oem_hdr)
            oem_blob_base = (const UBYTE *)h;
#endif
        oem_bundle_valid = true;
    }
}
#endif

static void set_bootmenu_palette(void)
{
    struct ViewPort *vp = &screen->ViewPort;
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI) || defined(OEM_KICKMODULE)
    const struct oem_variant *variant = oem_selected_variant();
    if (variant) {
        int num_colors = 1 << oem_variant_depth(oem_selected_slot);
        for (int i = 0; i < num_colors; i++) {
            uint16_t rgb = variant->palette[i];
            SetRGB4(vp, i, (rgb >> 8) & 0xF, (rgb >> 4) & 0xF, rgb & 0xF);
        }
        return;
    }
#endif

    /* Set up palette */
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
    /* Flash-backed boards: pen 4 (PCB) from NVRAM, default dark gray */
    SetRGB4(vp, 4, asave->menu_color_r, asave->menu_color_g, asave->menu_color_b);
#else
    SetRGB4(vp, 4, 4, 4, 4);
#endif
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI) || defined(OEM_KICKMODULE)
    oem_selected_slot = -1;
#endif
    SetRGB4(vp, 5, 12, 10, 0);  /* Gold for Zorro connector */
    SetRGB4(vp, 6, 11, 6, 6);   /* Red for DIP switches */
}

static bool init_bootmenu(void)
{
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI) || defined(OEM_KICKMODULE)
    if (oem_bundle_valid) {
        for (int slot = 0; slot < OEM_VARIANT_SLOTS; slot++) {
            if (!oem_variant_present(slot))
                continue;
            if (open_bootmenu_screen(oem_variant_depth(slot))) {
                oem_selected_slot = slot;
                break;
            }
        }
    }
#endif

    if (!screen && !open_bootmenu_screen(3))
        return false;

    set_bootmenu_palette();
    return true;
}

static void close_libraries(void)
{
    CloseLibrary(IntuitionBase);
    CloseLibrary((struct Library *)GfxBase);
    CloseLibrary(GadToolsBase);
}

static void cleanup_bootmenu(void)
{
    if (window) {
        CloseWindow(window);
        window = NULL;
    }
    if (visualInfo) {
        FreeVisualInfo(visualInfo);
        visualInfo = NULL;
    }
    if (screen) {
        CloseScreen(screen);
        screen = NULL;
    }
    if (gadgets) {
        FreeGadgets(gadgets);
        gadgets = NULL;
    }
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI) || defined(OEM_KICKMODULE)
    oem_free_cache();
    oem_selected_slot = -1;
#endif
    close_libraries();
}

static struct Gadget *create_gadget(UWORD kind)
{
    const struct TagItem tags[] = {
        { GT_Underscore, '~' },
        { TAG_DONE, 0 }
    };
    return(CreateGadgetA(kind,LastAdded,NewGadget,tags));
}

static void Print(STRPTR text, UWORD x, UWORD y, int center)
{
    struct RastPort *rp = &screen->RastPort;
    int len=strlen(text);
    while(len && (text[len-1] == 10 || text[len-1] == 13))
        len--;
    if (center)
        x += (WIDTH-TextLength(rp,text,len))/2;
    Move(rp,x,y);
    Text(rp,text,len);
}

static void page_header(struct NewGadget *ng, STRPTR title, BOOL welcome)
{
    struct RastPort *rp = &screen->RastPort;
    if (gadgets)
    {
        RemoveGList(window,gadgets,-1);
        FreeGadgets(gadgets);
        DisplayTypeGad = NULL;
        LastAdded = NULL;
        SetRast(&screen->RastPort,0);
    }
    SetAPen(rp,2);
    Print(title,0,13,TRUE);

    gadgets = CreateContext(&LastAdded);

    NewGadget  = ng;
    ng->ng_TextAttr   = NULL;
    ng->ng_Flags      = 0;
    ng->ng_VisualInfo = visualInfo;
    ng->ng_Width      = 87;
    ng->ng_Height     = 14;
    ng->ng_TopEdge    = 183;

    if (welcome) {
        SetAPen(rp,1);
#if defined(DRIVER_A4091)
        Print("Welcome to your Amiga 4091 Zorro III SCSI-2 Host Controller",0,32,TRUE);
#elif defined(DRIVER_A4092)
        Print("Welcome to your Amiga 4092 Zorro III SCSI-2 Host Controller",0,32,TRUE);
#elif defined(DRIVER_A4770)
        Print("Welcome to your Amiga 4770 Cheetah Zorro III SCSI Host Controller",0,32,TRUE);
#elif defined(DRIVER_A4000T)
        Print(" Welcome to Amiga 4000(T) SCSI Configuration & Diagnostics",0,32,TRUE);
#elif defined(DRIVER_A4000T770)
        Print("Welcome to Amiga 4000D+ UW SCSI Configuration & Diagnostics",0,32,TRUE);
#endif
#if defined(NCR53C710)
        Print("This project is brought to you by Chris Hooper and Stefan Reinauer",0,44,TRUE);
#else
        Print("This project is brought to you by Stefan Reinauer",0,44,TRUE);
#endif
    }
}

static void page_footer(void)
{
    AddGList(window,gadgets,-1,-1,NULL);
    RefreshGList(gadgets,window,NULL,-1);
    GT_RefreshWindow(window,NULL);
}

static void draw_dipswitch(UWORD x, UWORD y, UWORD off)
{
    struct RastPort *rp = &screen->RastPort;

    /* Draw gray box (recessed: black top/left, white bottom/right) */
    SetAPen(rp, 0);
    RectFill(rp, x+10, y, x+52, y+8);
    /* Gray box - black top edge */
    SetAPen(rp, 1);
    Move(rp, x+10, y); Draw(rp, x+52, y);
    /* Gray box - black left edge */
    Move(rp, x+10, y); Draw(rp, x+10, y+8);
    /* Gray box - white bottom edge */
    SetAPen(rp, 2);
    Move(rp, x+10, y+8); Draw(rp, x+52, y+8);
    /* Gray box - white right edge */
    Move(rp, x+52, y); Draw(rp, x+52, y+8);

    /* Position slider based on switch state */
    if (!off)
        x+= 20;

    /* White slider (raised: white top/left, black bottom/right) */
    SetAPen(rp, 2);
    RectFill(rp, x+12, y+2, x+30, y+6);
    /* White slider - white top edge */
    SetAPen(rp, 2);
    Move(rp, x+12, y+2); Draw(rp, x+30, y+2);
    /* White slider - white left edge */
    Move(rp, x+12, y+2); Draw(rp, x+12, y+6);
    /* White slider - black bottom edge */
    SetAPen(rp, 1);
    Move(rp, x+12, y+6); Draw(rp, x+30, y+6);
    /* White slider - black right edge */
    Move(rp, x+30, y+2); Draw(rp, x+30, y+6);
}

static char *dipswitch_text(int val, int num)
{
    static char string[25];
    string[0]=0;
    switch (num) {
#if defined(DRIVER_A4000T770)
      case 8: strcat((char *)string, "Termination High ");
              strcat((char *)string, val?"Off":"On");
              break;
      case 7: strcat((char *)string, "Termination Low ");
              strcat((char *)string, val?"Off":"On");
              break;
#else
      case 8: strcat((char *)string, "SCSI LUNs ");
              strcat((char *)string, val?"Disabled":"Enabled");
              break;
      case 7: strcat((char *)string, "External Termination ");
              strcat((char *)string, val?"On":"Off");
              break;
#endif
      case 6: strcat((char *)string, val?"S":"As");
              strcat((char *)string, "ynchronous SCSI Mode");
              break;
      case 5: strcat((char *)string, val?"Short":"Long");
              strcat((char *)string, " Spinup Mode");
              break;
      case 4: strcat((char *)string, val?"SCSI-2 Fast":"SCSI-1 Slow");
              strcat((char *)string, " Bus Mode");
              break;
#if defined(DRIVER_A4000T770)
      case 3: strcat((char *)string, "SCSI LUNs ");
              strcat((char *)string, val?"Disabled":"Enabled");
              break;
      case 2: strcat((char *)string, val?"Non-Ultra":"Ultra");
              break;
      case 1: strcat((char *)string, val?"Narrow":"Wide");
              break;
#else
      case 3:
      case 2:
      case 1: strcat((char *)string, "SCSI Address A? = ?");
              string[14] = num - 1 + '0';
              string[18] = val + '0';
              break;
#endif
    }

    return  string;
}

#if !defined(DRIVER_A4000T770) || defined(FLASH_PARALLEL) || defined(FLASH_SPI)
static void format_host_id(char *buf, UBYTE host_id)
{
    strcpy(buf, "Host ID: ");
    if (host_id >= 10) {
        buf[9] = '0' + (host_id / 10);
        buf[10] = '0' + (host_id % 10);
        buf[11] = 0;
    } else {
        buf[9] = '0' + host_id;
        buf[10] = 0;
    }
}
#endif

static void draw_dipswitches(UWORD x, UWORD y)
{
    struct RastPort *rp = &screen->RastPort;
    int i;
    UBYTE dip_switches;
    char *ret;
    char num[] = "8";
#if !defined(DRIVER_A4000T770)
    char hostid[13];
#endif

    if (asave) {
        dip_switches = get_dip_switches();
        printf("addr=%x\n",asave->as_addr);
        printf("dip_switches=%x\n",dip_switches);
    } else {
        dip_switches = 0xff;
    }

    SetAPen(rp, 1);
    SetBPen(rp, 0);
    Move(rp, x+16, y);
    Text(rp, "Off/On",6);

    /* Draw red box with raised 3D border (white top/left, black bottom/right) */
    SetAPen(rp, 6);
    RectFill(rp, x, y+2, x+70, y+90);
    /* Raised - white top edge */
    SetAPen(rp, 2);
    Move(rp, x, y+2); Draw(rp, x+70, y+2);
    /* Raised - white left edge */
    Move(rp, x, y+2); Draw(rp, x, y+90);
    /* Raised - black bottom edge */
    SetAPen(rp, 1);
    Move(rp, x, y+90); Draw(rp, x+70, y+90);
    /* Raised - black right edge */
    Move(rp, x+70, y+2); Draw(rp, x+70, y+90);

    for (i=0; i<8; i++) {
        draw_dipswitch(x+8, y+7+(i*10), dip_switches&BIT(7-i));
    }

    SetAPen(rp, 1);
    for (i=0; i<8; i++) {
        SetBPen(rp, 6);
        Move(rp, x+6,y+(i*10)+14);
        num[0] = '8' - i;
        Text(rp, (char *)num, 1);
        Move(rp, x+82,y+(i*10)+14);
        SetBPen(rp, 0);
        ret = dipswitch_text(dip_switches&BIT(7-i), 8-i);
        Text(rp, (char *)ret, strlen((char *)ret));
    }

#if !defined(DRIVER_A4000T770)
    format_host_id(hostid, get_host_id());
    Move(rp, x+280, y+64);
    Text(rp, (char *)hostid, strlen(hostid));
#endif
    BNDRYOFF(rp);
}

#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
/* Redraw only one DIP switch row and its description to avoid flicker */
static void redraw_dip_row(UWORD base_x, UWORD base_y, int row, UBYTE dip_switches)
{
    struct RastPort *rp = &screen->RastPort;
    if (row < 0 || row > 7) return;

    /* Redraw the switch slider */
    draw_dipswitch(base_x + 8, base_y + 7 + (row * 10), dip_switches & BIT(7 - row));

    /* Redraw the textual description on the right side */
    SetAPen(rp, 1);
    SetBPen(rp, 0);
    Move(rp, base_x + 82, base_y + (row * 10) + 14);
    /* Clear previous text by printing spaces over a safe width */
    Text(rp, "                        ", 24);
    Move(rp, base_x + 82, base_y + (row * 10) + 14);
    char *ret = dipswitch_text(dip_switches & BIT(7 - row), 8 - row);
    Text(rp, (char *)ret, strlen((char *)ret));
}

static void redraw_host_id(UWORD base_x, UWORD base_y, UBYTE dip_switches)
{
    struct RastPort *rp = &screen->RastPort;
    char hostid[13];
#if defined(DRIVER_A4000T770)
    (void)dip_switches;
    format_host_id(hostid, get_host_id());
#else
    format_host_id(hostid, dip_switches & 7);
#endif
    SetAPen(rp, 1);
    SetBPen(rp, 0);
    Move(rp, base_x + 280, base_y + 64);
    Text(rp, "            ", 12);
    Move(rp, base_x + 280, base_y + 64);
    Text(rp, hostid, strlen(hostid));
}
#endif

static void dipswitch_page(void)
{
    struct NewGadget ng;
    current_page = 2;
    page_header(&ng, BOOTMENU_NAME " Diagnostics - DIP switches", TRUE);

    ng.ng_LeftEdge   = 400;
    ng.ng_TopEdge    = 145;
    ng.ng_Width      = 120;
    ng.ng_GadgetText = "~Back";
    ng.ng_GadgetID   = DIPSWITCH_BACK_ID;
    LastAdded = create_gadget(BUTTON_KIND);

    DrawBevelBox(&screen->RastPort,100,52,440,115,
                                    GT_VisualInfo,  visualInfo,
                                    GTBB_Recessed,  TRUE,
                                    GTBB_FrameType, BBFT_RIDGE,
                                    TAG_DONE);
    draw_dipswitches(120,65);

    page_footer();
}

#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
static void show_toast(STRPTR text)
{
    /* Brief on-screen message near the bottom; ~1s */
    struct RastPort *rp = &screen->RastPort;
    UWORD len = strlen(text);
    UWORD x = (640 - len * 8) / 2, y = 191;
    SetAPen(rp, 2);
    SetBPen(rp, 0);
    Move(rp, x, y);
    Text(rp, text, len);
    /* Wait ~1 second */
    for (int i = 0; i < 60; i++) WaitTOF();
    /* Clear */
    Move(rp, x, y);
    Text(rp, "                          ", 26);
}
#endif

static void about_page(void)
{
    struct NewGadget ng;
    current_page = 3;
    page_header(&ng, "About " BOOTMENU_NAME, TRUE);

    SetAPen(&screen->RastPort, 1);
#if defined(DRIVER_A4091) || defined(DRIVER_A4092) || defined(DRIVER_A4770)
    Print("Thank you to Dave Haynie, Scott Schaeffer, Greg", 118,68,FALSE);
    Print("Berlin and Terry Fisher for the original A4091.",118,77,FALSE);
#elif defined(DRIVER_A4000T) || defined(DRIVER_A4000T770)
    Print("Thank you to the Amiga engineers for a wonderful", 118,68,FALSE);
    Print("machine that passed the test of time.",118,77,FALSE);
#endif
    Print("Driver based on the NetBSD/Amiga SCSI subsystem and",118,86,FALSE);
#if defined(NCR53C710)
    Print("NCR53C710 code by many fine contributors over the",118,95,FALSE);
#elif defined(NCR53C770)
    Print("NCR53C770 code by many fine contributors over the",118,95,FALSE);
#endif
    Print("years. Original RDB mounter by Toni Wilen.",118,104,FALSE);
    Print("Only Amiga makes it possible.", 204,127,FALSE);
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
    if (asave->mfg_serial[0])
        Print(asave->mfg_serial, 110, 155, FALSE);
#endif
    Print((char *)device_id_string, 100,178,FALSE);

    ng.ng_LeftEdge   = 400;
    ng.ng_TopEdge    = 145;
    ng.ng_Width      = 120;
    ng.ng_GadgetText = "~Back";
    ng.ng_GadgetID   = ABOUT_BACK_ID;
    LastAdded = create_gadget(BUTTON_KIND);

    DrawBevelBox(&screen->RastPort,100,52,440,115,
                                    GT_VisualInfo,  visualInfo,
                                    GTBB_Recessed,  TRUE,
                                    GTBB_FrameType, BBFT_RIDGE,
                                    TAG_DONE);
    page_footer();
}

static char *
trim_spaces(char *str, size_t len)
{
    size_t olen = len;
    char *ptr;

    for (ptr = str; len > 0; ptr++, len--)
        if (*ptr != ' ')
            break;

    if (len == 0) {
        /* Completely empty name */
        *str = '\0';
        return (str);
    } else {
        CopyMem(ptr, str, len);

        while ((len > 0) && (str[len - 1] == ' '))
            len--;

        if (len < olen)  /* Is there space for a NIL character? */
            str[len] = '\0';
        return (str);
    }
    return (str);
}

static const char *
devtype_str(uint dtype)
{
    static const char dt_list[][8] = {
        "Disk", "Tape", "Printer", "Proc",
        "Worm", "CDROM", "Scanner", "Optical",
        "Changer", "Comm", "ASCIT81", "ASCIT82",
    };
    if (dtype < ARRAY_SIZE(dt_list))
        return (dt_list[dtype]);
    return ("Unknown");
}

static char _itoabuf[12]; // MAXINT
static int scan_disks(void)
{
    int i;
    int cnt=0;
    struct MsgPort *port = NULL;
    struct IOExtTD *request = NULL;
    struct RastPort *rp = &screen->RastPort;
    UBYTE hostid;
    int max_targets;
    int max_luns;

    int x,y;
    printf("Looking for disks!\n");

    port = W_CreateMsgPort(SysBase);
    if(!port) {
        printf("failed.\n");
        return 0;
    }

    request = (struct IOExtTD*)W_CreateIORequest(port, sizeof(struct IOExtTD), SysBase);
    if(!request) {
        printf("failed.\n");
        W_DeleteMsgPort(port, SysBase);
        return 0;
    }

    // Get the host controller ID and determine max targets and LUNs
    if (asave) {
        hostid = get_host_id();
        max_luns = get_lun_count();
#ifdef NCR53C770
        max_targets = get_target_count();
#else
        // NCR53C710 and A4091 support 8 targets (0-7)
        max_targets = 8;
#endif
    } else {
        // Default when not initialized - assume host at ID 7 and LUNs disabled
        hostid = 7;
#ifdef NCR53C770
        max_targets = 16;
#else
        max_targets = 8;
#endif
        max_luns = 1;
    }

    for (i=0; i<max_targets; i++) {
        // Skip the host controller ID
        if (i == hostid)
            continue;
        
        int lun;
        for (lun = 0; lun < max_luns; lun++) {
            // Stop if we've filled the display (14 lines max)
            if (cnt >= 14)
                break;
                
            x=52;
            y=52+(cnt*10);

            ULONG unitNum = calculate_unit_number(i, lun);
            printf("OpenDevice('%s', %"PRId32", %p, 0)\n", real_device_name, unitNum, request);
            UBYTE err = OpenDevice(real_device_name, unitNum, (struct IORequest*)request, 0);
            if (err == 0) {
                scsi_inquiry_data_t inq_res;

                err = dev_scsi_inquiry(request, unitNum, &inq_res);

                trim_spaces(inq_res.vendor, sizeof (inq_res.vendor));
                trim_spaces(inq_res.product, sizeof (inq_res.product));
                trim_spaces(inq_res.revision, sizeof (inq_res.revision));

                if (err == 0) {
                    unsigned int t_len;
                    int target, lun;
                    char unit_str[5];

                    decode_unit_number(unitNum, &target, &lun);

                    if (target > 9) {
                        unit_str[0] = '1';
                        unit_str[1] = '0' + (target - 10);
                        unit_str[2] = '.';
                        unit_str[3] = '0' + lun;
                        unit_str[4] = 0;
                    } else {
                        unit_str[0] = '0' + target;
                        unit_str[1] = '.';
                        unit_str[2] = '0' + lun;
                        unit_str[3] = 0;
                    }

                    Move(rp,x,y);
                    Text(rp, (char *)unit_str, strlen(unit_str));
                    x+=48;
                    Move(rp,x,y);
                    t_len = strlen(inq_res.vendor);
                    if (t_len > sizeof(inq_res.vendor))
                            t_len=sizeof(inq_res.vendor);
                    Text(rp, inq_res.vendor, t_len);
                    x+=96;
                    Move(rp,x,y);
                    t_len = strlen(inq_res.product);
                    if (t_len > sizeof(inq_res.product))
                            t_len=sizeof(inq_res.product);
                    Text(rp, inq_res.product, t_len);
                    x+=176;
                    Move(rp,x,y);
                    t_len = strlen(inq_res.revision);
                    if (t_len > sizeof(inq_res.revision))
                            t_len=sizeof(inq_res.revision);
                    Text(rp, inq_res.revision, t_len);
                    x+=48;
                    Move(rp,x,y);
                    const char *dtype=devtype_str(inq_res.device & SID_TYPE);
                    Text(rp,dtype,strlen(dtype));
                    printf(" %-*.*s %-*.*s %-*.*s %-7s\n",
                           sizeof (inq_res.vendor), sizeof (inq_res.vendor),
                           inq_res.vendor,
                           sizeof (inq_res.product), sizeof (inq_res.product),
                           inq_res.product,
                           sizeof (inq_res.revision), sizeof (inq_res.revision),
                           inq_res.revision,
                           devtype_str(inq_res.device & SID_TYPE));
                }

                struct DriveGeometry geom;
                if (dev_scsi_get_drivegeometry(request, &geom) == 0) {
                    uint ssize = geom.dg_SectorSize;
                    uint cap   = geom.dg_TotalSectors / 1000;
                    uint cap_c = 0;  // KMGTPEZY
                    if (cap > 100000) {
                        cap /= 1000;
                        cap_c++;
                    }
                    cap *= ssize;
                    while (cap > 9999) {
                        cap /= 1000;
                        cap_c++;
                    }
                    printf("%5u %5u %cB\n", ssize, cap, "KMGTPEZY"[cap_c]);

                    x+=76;
                    Move(rp,x,y);
                    if (ssize<1000)
                        Text(rp," ",1);
                    itoa(ssize,_itoabuf,10);
                    Text(rp,_itoabuf,strlen(_itoabuf));

                    x+=48;
                    Move(rp,x,y);
                    if(cap<1000)
                        Text(rp," ",1);
                    if(cap<100)
                        Text(rp," ",1);
                    itoa(cap,_itoabuf,10);
                    Text(rp,_itoabuf,strlen(_itoabuf));
                    const char caps[]="KMGTPEZY";
                    Text(rp,&caps[cap_c],1);
                    Text(rp,"B",1);
                }
                CloseDevice((struct IORequest*)request);
                cnt++;
            }
        }
        
        // Stop if we've filled the display
        if (cnt >= 14)
            break;
    }

    W_DeleteIORequest(request, SysBase);
    W_DeleteMsgPort(port, SysBase);
    return 0;
}

static const struct Rectangle disk_table[] =
{
    { 40, 28,560,148},
    { 42, 29, 49, 12}, // Unit
    { 42, 42, 49,133},
    { 92, 29, 95, 12}, // Vendor
    { 92, 42, 95,133},
    {188, 29,175, 12}, // Device
    {188, 42,175,133},
    {364, 29, 49, 12}, // Revision
    {364, 42, 49,133},
    {414, 29, 71, 12}, // Type
    {414, 42, 71,133},
    {486, 29, 47, 12}, // ssize
    {486, 42, 47,133},
    {534, 29, 64, 12}, // Cap
    {534, 42, 64,133}
};

static void disks_page(void)
{
    struct NewGadget ng;
    int i;
    ULONG tag;
    current_page = 1;
    page_header(&ng, BOOTMENU_NAME " Diagnostics - Disks", FALSE);

    SetAPen(&screen->RastPort,2);
    Print("Unit  Vendor      Device                Rev.  Type     Blk   Size",52,38,FALSE);
    SetAPen(&screen->RastPort,1);

    ng.ng_LeftEdge   = 400;
    ng.ng_TopEdge    = 185;
    ng.ng_Width      = 120;
    ng.ng_GadgetText = "~Back";
    ng.ng_GadgetID   = DISKS_BACK_ID;
    LastAdded = create_gadget(BUTTON_KIND);

    tag=GTBB_Recessed;
    for (i = 0; i < 15; i++)
    {
        DrawBevelBox(&screen->RastPort,disk_table[i].MinX,disk_table[i].MinY,
                                       disk_table[i].MaxX+1,
                                       disk_table[i].MaxY+1,
                                       GT_VisualInfo,  visualInfo,
                                       tag,            TRUE,
                                       TAG_DONE);
        tag = TAG_IGNORE;
    }

    page_footer();

    scan_disks();
}

static void debug_page(void)
{
    struct NewGadget ng;
    current_page = 4;
    page_header(&ng, BOOTMENU_NAME " Diagnostics - Debug", TRUE);

    BOOL cdrom_boot = asave->cdrom_boot ? TRUE : FALSE;
    BOOL ignore_last = asave->ignore_last ? TRUE : FALSE;
#ifdef ENABLE_QUICKINTS
    BOOL quick_int = asave->quick_int ? TRUE : FALSE;
#endif
    BOOL allow_disc = asave->allow_disc ? TRUE : FALSE;

    ng.ng_LeftEdge   = 400;
    ng.ng_TopEdge    = 60;
    ng.ng_Width      = 175;
    ng.ng_GadgetText = "~CDROM Boot";
    ng.ng_GadgetID   = DEBUG_CDROM_BOOT_ID;
    LastAdded = create_gadget(CHECKBOX_KIND);
    GT_SetGadgetAttrs(LastAdded, NULL, NULL, GTCB_Checked, cdrom_boot, TAG_DONE);

    ng.ng_TopEdge    = 76;
    ng.ng_GadgetText = "Scan past ~RDBFF_LAST";
    ng.ng_GadgetID   = DEBUG_IGNORE_LAST_ID;
    LastAdded = create_gadget(CHECKBOX_KIND);
    GT_SetGadgetAttrs(LastAdded, NULL, NULL, GTCB_Checked, ignore_last, TAG_DONE);

    ng.ng_TopEdge    = 92;
#ifdef ENABLE_QUICKINTS
    ng.ng_GadgetText = "~Quick Interrupts";
    ng.ng_GadgetID   = DEBUG_QUICK_INT_ID;
    LastAdded = create_gadget(CHECKBOX_KIND);
    GT_SetGadgetAttrs(LastAdded, NULL, NULL, GTCB_Checked, quick_int, TAG_DONE);

    ng.ng_TopEdge    = 108;
#endif
    ng.ng_GadgetText = "Al~low Disconnect";
    ng.ng_GadgetID   = DEBUG_ALLOW_DISC_ID;
    LastAdded = create_gadget(CHECKBOX_KIND);
    GT_SetGadgetAttrs(LastAdded, NULL, NULL, GTCB_Checked, allow_disc, TAG_DONE);

    ng.ng_TopEdge   += 16;
#if 0
    ng.ng_GadgetText = "~Zorro III magic speed hack";
    ng.ng_GadgetID   = DEBUG_BOGUS_ID;
    LastAdded = create_gadget(CHECKBOX_KIND);
    GT_SetGadgetAttrs(LastAdded, NULL, NULL, GA_Disabled, TRUE, TAG_DONE);
#endif

    ng.ng_LeftEdge   = 400;
    ng.ng_TopEdge    = 145;
    ng.ng_Width      = 120;
    ng.ng_GadgetText = "~Back";
    ng.ng_GadgetID   = DEBUG_BACK_ID;
    LastAdded = create_gadget(BUTTON_KIND);

    DrawBevelBox(&screen->RastPort,100,52,440,115,
                                    GT_VisualInfo,  visualInfo,
                                    GTBB_Recessed,  TRUE,
                                    GTBB_FrameType, BBFT_RIDGE,
                                    TAG_DONE);

    page_footer();
}

struct drawing {
    BYTE type, pen; // 1: rectangle filled 2: rectangle empty -1: end
    SHORT x, y, w, h;
};

#if defined(DRIVER_A4091)
#include "util/artwork/assets/a4091.h"
#define ART_X_OFFSET 103
#define ART_Y_OFFSET 50

#define HAVE_ARTWORK
#elif defined(DRIVER_A4092)
#include "util/artwork/assets/a4092.h"
#define ART_X_OFFSET 206
#define ART_Y_OFFSET 50

#define HAVE_ARTWORK
#else
#undef HAVE_ARTWORK
#define ART_Y_OFFSET 50
#endif

#ifdef HAVE_ARTWORK
static void draw_card(const struct drawing c[], int length)
{
    struct RastPort *rp = &screen->RastPort;
    int x=ART_X_OFFSET, y=ART_Y_OFFSET, i,j;

    for (i=0; i<length; i++) {
        struct drawing d = c[i];
        UBYTE type=d.type, pen=d.pen;
        SHORT x1=x+d.x, y1=y+d.y/2, x2=x+d.x+d.w, y2=y+d.y/2+d.h/2;
        SetAPen(rp, pen);
        switch (type) {
        case 1:
	    // filled rectangle
            RectFill(rp, x1, y1, x2, y2);
            break;
        case 2:
	    // unfilled rectangle
            Move(rp, x1, y1);
            Draw(rp, x2, y1);
            Draw(rp, x2, y2);
            Draw(rp, x1, y2);
            Draw(rp, x1, y1);
            break;
        case 3:
	    // Zorro pins (uses pen from data for gold color)
            for(j=x1; j<x2; j+=4) {
                RectFill(rp, j, y1, j+1, y2);
            }
        }
    }
}
#else
#define draw_card(x,y)
#endif

#if defined(FLASH_PARALLEL) || defined(FLASH_SPI) || defined(OEM_KICKMODULE)
static bool prepare_oem_image(void)
{
    const struct oem_variant *variant = oem_selected_variant();
    const UBYTE *comp_src = NULL;
    UBYTE *comp_buf = NULL;
    int bpr;

    if (!variant)
        return false;
    if (oem_bitmap_data)
        return true;

#ifdef OEM_KICKMODULE
    if (oem_blob_base)
        comp_src = oem_blob_base + variant->data_offset;
#endif
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
    if (!comp_src) {
        comp_buf = (UBYTE *)AllocMem(variant->compressed_size, MEMF_PUBLIC);
        if (!comp_buf)
            return false;
        if (!flash_readBuf(OEM_FLASH_OFFSET + variant->data_offset,
                           comp_buf, variant->compressed_size)) {
            FreeMem(comp_buf, variant->compressed_size);
            return false;
        }
        comp_src = comp_buf;
    }
#endif

    if (!comp_src)
        return false;

    /* BltBitMap may use the blitter, so source planes must be chip-accessible. */
    oem_bitmap_data = (UBYTE *)AllocMem(variant->uncompressed_size,
                                        MEMF_PUBLIC | MEMF_CHIP);
    if (!oem_bitmap_data) {
        if (comp_buf)
            FreeMem(comp_buf, variant->compressed_size);
        return false;
    }
    oem_bitmap_size = variant->uncompressed_size;

    zx0_decompress(comp_src, oem_bitmap_data);
    if (comp_buf)
        FreeMem(comp_buf, variant->compressed_size);

    /* Set up a non-interleaved source BitMap pointing into decompressed data */
    memset(&oem_bitmap, 0, sizeof(oem_bitmap));
    InitBitMap(&oem_bitmap, oem_variant_depth(oem_selected_slot),
               variant->width, variant->height);
    bpr = oem_bitmap.BytesPerRow;

    for (int i = 0; i < oem_variant_depth(oem_selected_slot); i++) {
        oem_bitmap.Planes[i] = (PLANEPTR)(oem_bitmap_data +
                                          i * bpr * variant->height);
    }

    oem_draw_x = oem_resolve_coord(variant->x, screen->Width, variant->width);
    oem_draw_y = oem_resolve_coord(variant->y, screen->Height, variant->height);
    return true;
}

static bool display_oem_image(void)
{
    const struct oem_variant *variant = oem_selected_variant();

    if (!variant)
        return false;
    if (!prepare_oem_image()) {
        oem_selected_slot = -1;
        oem_free_cache();
        set_bootmenu_palette();
        return false;
    }

    BltBitMap(&oem_bitmap, 0, 0,
              screen->RastPort.BitMap,
              oem_draw_x, oem_draw_y,
              variant->width, variant->height,
              0xC0, 0xFF, NULL);
    WaitBlit();
    return true;
}

#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
static const struct Rectangle mfg_table[] =
{
    { 40, 20,560,162},
    { 42, 21,148, 12}, // Label header
    { 42, 34,148,147}, // Label data
    {192, 21,406, 12}, // Value header
    {192, 34,406,147}, // Value data
};

static void epoch_to_ymd(uint32_t ts, int *year, int *month, int *day)
{
    static const int mdays[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    uint32_t days = ts / 86400;
    int y = 1970;
    int leap, m;

    for (;;) {
        leap = (y % 4 == 0 && (y % 100 != 0 || y % 400 == 0));
        if (days < (uint32_t)(365 + leap))
            break;
        days -= 365 + leap;
        y++;
    }

    for (m = 0; m < 12; m++) {
        int md = mdays[m] + (m == 1 && leap);
        if (days < (uint32_t)md)
            break;
        days -= md;
    }

    *year = y;
    *month = m + 1;
    *day = (int)days + 1;
}

static void mfg_print_row(int row, const char *label, const char *value)
{
    struct RastPort *rp = &screen->RastPort;
    UWORD y = 43 + row * 9;
    SetAPen(rp, 2);
    Move(rp, 52, y);
    Text(rp, label, strlen(label));
    SetAPen(rp, 1);
    Move(rp, 202, y);
    Text(rp, value, strlen(value));
}

/* Format "major.minor" from a uint16_t version (high byte.low byte) */
static void fmt_version(char *buf, uint16_t ver)
{
    char *p = buf;
    itoa(ver >> 8, p, 10);
    p += strlen(p);
    *p++ = '.';
    itoa(ver & 0xFF, p, 10);
}

/* Format "YYYY-MM-DD" from epoch_to_ymd results */
static void fmt_date(char *buf, int y, int m, int d)
{
    buf[0] = '0' + (y / 1000);
    buf[1] = '0' + ((y / 100) % 10);
    buf[2] = '0' + ((y / 10) % 10);
    buf[3] = '0' + (y % 10);
    buf[4] = '-';
    buf[5] = '0' + (m / 10);
    buf[6] = '0' + (m % 10);
    buf[7] = '-';
    buf[8] = '0' + (d / 10);
    buf[9] = '0' + (d % 10);
    buf[10] = '\0';
}

/* Copy a fixed-length field into buf with null termination */
static void mfg_copy_field(char *buf, const char *src, int len)
{
    memcpy(buf, src, len);
    buf[len] = '\0';
}

static void mfg_page(void)
{
    static const char hex[] = "0123456789ABCDEF";
    struct NewGadget ng;
    struct mfg_data mfg;
    uint8_t *p = (uint8_t *)&mfg;
    uint32_t i;
    char buf[48];
    char title[64];
    BOOL valid, cksum_ok = FALSE;
    ULONG tag;

    /* Read manufacturing data from flash */
    for (i = 0; i < sizeof (mfg); i++)
        p[i] = flash_readByte(MFG_FLASH_OFFSET + i);

    /* Validate magic */
    valid = (mfg.magic == MFG_MAGIC);

    /* Verify XOR32 checksum */
    if (valid) {
        uint32_t *words = (uint32_t *)&mfg;
        uint32_t xor = 0;
        for (i = 0; i < sizeof (mfg) / sizeof (uint32_t); i++)
            xor ^= words[i];
        cksum_ok = (xor == 0);
    }

    /* Build title with checksum status */
    if (!valid)
        strcpy(title, BOOTMENU_NAME " Diagnostics - Manufacturing");
    else if (cksum_ok)
        strcpy(title, BOOTMENU_NAME " Manufacturing - Checksum OK");
    else
        strcpy(title, BOOTMENU_NAME " Manufacturing - BAD CHECKSUM");

    current_page = 5;
    page_header(&ng, title, FALSE);

    /* Draw bevel box table */
    tag = GTBB_Recessed;
    for (i = 0; i < ARRAY_LENGTH(mfg_table); i++) {
        DrawBevelBox(&screen->RastPort,
                     mfg_table[i].MinX, mfg_table[i].MinY,
                     mfg_table[i].MaxX + 1,
                     mfg_table[i].MaxY + 1,
                     GT_VisualInfo, visualInfo,
                     tag, TRUE,
                     TAG_DONE);
        tag = TAG_IGNORE;
    }

    /* Column headers */
    SetAPen(&screen->RastPort, 2);
    Print("Field", 52, 30, FALSE);
    Print("Value", 202, 30, FALSE);

    if (!valid) {
        SetAPen(&screen->RastPort, 1);
        Print("No manufacturing data found", 0, 110, TRUE);
    } else {
        int y, m, d;

        /* Card Type */
        mfg_copy_field(buf, mfg.card_type, sizeof (mfg.card_type));
        mfg_print_row(0, "Card Type", buf);

        /* Serial */
        mfg_copy_field(buf, mfg.serial, sizeof (mfg.serial));
        mfg_print_row(1, "Serial", buf);

        /* SKU */
        mfg_copy_field(buf, mfg.sku, sizeof (mfg.sku));
        mfg_print_row(2, "SKU", buf);

        /* HW Revision */
        fmt_version(buf, mfg.hw_revision);
        mfg_print_row(3, "HW Revision", buf);

        /* PCB Color */
        buf[0] = '#';
        buf[1] = hex[PCB_COLOR_R(&mfg)];
        buf[2] = hex[PCB_COLOR_G(&mfg)];
        buf[3] = hex[PCB_COLOR_GET_B(&mfg)];
        buf[4] = '\0';
        mfg_print_row(4, "PCB Color", buf);

        /* Assembler */
        mfg_copy_field(buf, mfg.assembler_name, sizeof (mfg.assembler_name));
        mfg_print_row(5, "Assembler", buf);

        /* Factory */
        mfg_copy_field(buf, mfg.assembly_factory,
                       sizeof (mfg.assembly_factory));
        mfg_print_row(6, "Factory", buf);

        /* Build Date */
        if (mfg.build_date != 0) {
            epoch_to_ymd(mfg.build_date, &y, &m, &d);
            fmt_date(buf, y, m, d);
        } else {
            strcpy(buf, "-");
        }
        mfg_print_row(7, "Build Date", buf);

        /* Batch */
        itoa(mfg.batch_number, buf, 10);
        mfg_print_row(8, "Batch", buf);

        /* SIOP Date Code (BCD packed: byte 0 = YY, byte 1 = WW) */
        {
            uint8_t *dc = (uint8_t *)mfg.siop_datecode;
            unsigned yy = ((dc[0] >> 4) & 0x0F) * 10 + (dc[0] & 0x0F);
            unsigned ww = ((dc[1] >> 4) & 0x0F) * 10 + (dc[1] & 0x0F);
            buf[0] = '0' + (yy / 10);
            buf[1] = '0' + (yy % 10);
            buf[2] = '/';
            buf[3] = '0' + (ww / 10);
            buf[4] = '0' + (ww % 10);
            buf[5] = '\0';
        }
        mfg_print_row(9, "SIOP Date Code", buf);

        /* CPLD Version */
        fmt_version(buf, mfg.cpld_version);
        mfg_print_row(10, "CPLD Version", buf);

        /* Initial FW */
        fmt_version(buf, mfg.initial_fw_version);
        mfg_print_row(11, "Initial FW", buf);

        /* Test Date */
        if (mfg.test_date != 0) {
            epoch_to_ymd(mfg.test_date, &y, &m, &d);
            fmt_date(buf, y, m, d);
        } else {
            strcpy(buf, "-");
        }
        mfg_print_row(12, "Test Date", buf);

        /* Test FW */
        fmt_version(buf, mfg.test_fw_version);
        mfg_print_row(13, "Test FW", buf);

        /* Test Status */
        buf[0] = '0'; buf[1] = 'x';
        buf[2] = hex[(mfg.test_status >> 12) & 0xF];
        buf[3] = hex[(mfg.test_status >> 8) & 0xF];
        buf[4] = hex[(mfg.test_status >> 4) & 0xF];
        buf[5] = hex[mfg.test_status & 0xF];
        strcpy(buf + 6,
               (mfg.test_status & TEST_PASSED_ALL) == TEST_PASSED_ALL
               ? " (ALL PASS)" : " (PARTIAL)");
        mfg_print_row(14, "Test Status", buf);

        /* Owner */
        mfg_copy_field(buf, mfg.owner_name, sizeof (mfg.owner_name));
        mfg_print_row(15, "Owner", buf);
    }

    /* Back button */
    ng.ng_LeftEdge   = 400;
    ng.ng_TopEdge    = 185;
    ng.ng_Width      = 120;
    ng.ng_GadgetText = "~Back";
    ng.ng_GadgetID   = MFG_BACK_ID;
    LastAdded = create_gadget(BUTTON_KIND);

    page_footer();
}
#endif
#endif

static void main_page(void)
{
    struct NewGadget ng;

    current_page = 0;
    page_header(&ng, BOOTMENU_NAME " Early Startup Menu", TRUE);

#if defined(FLASH_PARALLEL) || defined(FLASH_SPI) || defined(OEM_KICKMODULE)
    if (!display_oem_image()) {
#endif
        draw_card(card, ARRAY_LENGTH(card));
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI) || defined(OEM_KICKMODULE)
    }
#endif

    ng.ng_LeftEdge   = 140;
    ng.ng_TopEdge    = 150;
    ng.ng_Width      = 175;
    ng.ng_GadgetText = "~Disks";
    ng.ng_GadgetID   = MAIN_DISKS_ID;
    LastAdded = create_gadget(BUTTON_KIND);

    ng.ng_TopEdge= 170;
    ng.ng_GadgetText = "DIP ~Switches";
    ng.ng_GadgetID   = MAIN_DIPSWITCH_ID;
    LastAdded = create_gadget(BUTTON_KIND);

    ng.ng_TopEdge= 150;
    ng.ng_LeftEdge   = 325;
    ng.ng_GadgetText = "~About";
    ng.ng_GadgetID   = MAIN_ABOUT_ID;
    LastAdded = create_gadget(BUTTON_KIND);

    ng.ng_TopEdge= 170;
    ng.ng_GadgetText = "Debu~g";
    ng.ng_GadgetID   = MAIN_DEBUG_ID;
    LastAdded = create_gadget(BUTTON_KIND);

    ng.ng_TopEdge= 200;
    if (GfxBase->DisplayFlags & NTSC) {
        ng.ng_TopEdge= 170;
        ng.ng_LeftEdge=538;
        ng.ng_Width = 88;
    }
    ng.ng_GadgetText = "~Boot";
    ng.ng_GadgetID   = MAIN_BOOT_ID;
    LastAdded = create_gadget(BUTTON_KIND);

    DrawBevelBox(&screen->RastPort,125,140,390,55,
                                    GT_VisualInfo,  visualInfo,
                                    GTBB_Recessed,  TRUE,
                                    GTBB_FrameType, BBFT_RIDGE,
                                    TAG_DONE);
    page_footer();
}

static void event_loop(void)
{
    ULONG class;
    UWORD icode;
    struct IntuiMessage *msg;
    struct Gadget *gad;
    int running = TRUE;

    while (running) {
        WaitPort(window->UserPort);
        if ((msg = GT_GetIMsg(window->UserPort))) {
            class = msg->Class;
            icode = msg->Code;
            gad = msg->IAddress;
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
            UWORD qual = msg->Qualifier;
            WORD mx = msg->MouseX;
            WORD my = msg->MouseY;
#endif
            GT_ReplyIMsg(msg);
            switch (class) {
            case IDCMP_RAWKEY:
                if (icode == 0x45) // key down ESC
                    running = FALSE;
                break;
            case IDCMP_VANILLAKEY:
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
                if (icode == 0x0D && (qual & IEQUALIFIER_CONTROL))
                    mfg_page();
#endif
                switch (icode) {
                case 'd':
                case 'D':
                    disks_page();
                    break;
                case 'a':
                case 'A':
                    about_page();
                    break;
                case 'g':
                case 'G':
                    debug_page();
                    break;
                case 's':
                case 'S':
                    dipswitch_page();
                    break;
                case 'b':
                case 'B':
                    if (current_page == 0) {
                        // We're on main page, so Boot
                        running = FALSE;
                    } else {
                        // We're on a sub-page, so Back to main
                        main_page();
                    }
                    break;
                case '1': case '2': case '3': case '4':
                case '5': case '6': case '7': case '8':
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
                    if (current_page == 2) { // DIP switches page
                        int sw = icode - '0'; // 1..8
                        int row = 8 - sw;     // map to row 0..7
                        UBYTE dips = get_dip_switches();
                        UBYTE new_dips = dips ^ BIT(7 - row);
                        *(volatile uint8_t *)(asave->as_addr + HW_OFFSET_SWITCHES) = new_dips;
                        asave->nvram.nv.settings.switch_flags = new_dips;
                        asave->nvram.switch_dirty = 1;
                        redraw_dip_row(120, 65, row, new_dips);
                        if (row >= 5) redraw_host_id(120, 65, new_dips);
                    }
#endif
                    break;
                case 'c':
                case 'C':
                    if (current_page == 4) { // Debug page
                        // Toggle CDROM Boot checkbox
                        asave->cdrom_boot = !asave->cdrom_boot;
                        Save_BattMem();
                        // Find and update the gadget directly instead of redrawing page
                        struct Gadget *cdrom_gad = gadgets;
                        while (cdrom_gad && cdrom_gad->GadgetID != DEBUG_CDROM_BOOT_ID)
                            cdrom_gad = cdrom_gad->NextGadget;
                        if (cdrom_gad)
                            GT_SetGadgetAttrs(cdrom_gad, window, NULL, GTCB_Checked, asave->cdrom_boot, TAG_DONE);
                    }
                    break;
                case 'r':
                case 'R':
                    if (current_page == 4) { // Debug page
                        // Toggle Ignore RDBFF_LAST checkbox
                        asave->ignore_last = !asave->ignore_last;
                        Save_BattMem();
                        // Find and update the gadget directly instead of redrawing page
                        struct Gadget *ignore_gad = gadgets;
                        while (ignore_gad && ignore_gad->GadgetID != DEBUG_IGNORE_LAST_ID)
                            ignore_gad = ignore_gad->NextGadget;
                        if (ignore_gad)
                            GT_SetGadgetAttrs(ignore_gad, window, NULL, GTCB_Checked, asave->ignore_last, TAG_DONE);
                    }
                    break;
#ifdef ENABLE_QUICKINTS
                case 'q':
                case 'Q':
                    if (current_page == 4) { // Debug page
                        // Toggle Quick Interrupts checkbox
                        asave->quick_int = !asave->quick_int;
                        Save_BattMem();
                        // Find and update the gadget directly instead of redrawing page
                        struct Gadget *quick_gad = gadgets;
                        while (quick_gad && quick_gad->GadgetID != DEBUG_QUICK_INT_ID)
                            quick_gad = quick_gad->NextGadget;
                        if (quick_gad)
                            GT_SetGadgetAttrs(quick_gad, window, NULL, GTCB_Checked, asave->quick_int, TAG_DONE);
                    }
                    break;
#endif
                case 'l':
                case 'L':
                    if (current_page == 4) { // Debug page
                        // Toggle Allow Disconnect checkbox
                        asave->allow_disc = !asave->allow_disc;
                        Save_BattMem();
                        // Find and update the gadget directly instead of redrawing page
                        struct Gadget *disc_gad = gadgets;
                        while (disc_gad && disc_gad->GadgetID != DEBUG_ALLOW_DISC_ID)
                            disc_gad = disc_gad->NextGadget;
                        if (disc_gad)
                            GT_SetGadgetAttrs(disc_gad, window, NULL, GTCB_Checked, asave->allow_disc, TAG_DONE);
                    }
                    break;
                case 'z':
                case 'Z':
                    if (current_page == 4) { // Debug page
                        // Zorro III magic speed hack is disabled, so do nothing
                    }
                    break;
                }
                break;
            case IDCMP_MOUSEBUTTONS:
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
                if (current_page == 2 && icode == SELECTDOWN) {
                    /* Check if click is within DIP switch area */
                    UWORD bx = 120, by = 65;
                    WORD relx = mx - bx;
                    WORD rely = my - by;
                    if (relx >= 0 && relx <= 200 && rely >= 0 && rely <= 100) {
                        /* Compute row based on y; rows every 10 px starting at +7 */
                        if (rely >= 7) {
                            int row = (rely - 7) / 10; // 0..7
                            if (row >= 0 && row < 8) {
                                /* Restrict x to switch slider region roughly */
                                if (relx >= 16 && relx <= 90) {
                                    UBYTE dips = get_dip_switches();
                                    UBYTE new_dips = dips ^ BIT(7 - row);
                                    *(volatile uint8_t *)(asave->as_addr + HW_OFFSET_SWITCHES) = new_dips;
                                    asave->nvram.nv.settings.switch_flags = new_dips;
                                    asave->nvram.switch_dirty = 1;
                                    redraw_dip_row(bx, by, row, new_dips);
                                    if (row >= 5) redraw_host_id(bx, by, new_dips);
                                }
                            }
                        }
                    }
                }
#endif
                break;
            case IDCMP_GADGETUP:
                switch (gad->GadgetID)
                {
                case MAIN_DISKS_ID:
                    disks_page();
                    break;
                case MAIN_DIPSWITCH_ID:
                    dipswitch_page();
                    break;
                case MAIN_ABOUT_ID:
                    about_page();
                    break;
                case MAIN_DEBUG_ID:
                    debug_page();
                    break;
                case DISKS_BACK_ID:
                case DIPSWITCH_BACK_ID:
                case ABOUT_BACK_ID:
                case DEBUG_BACK_ID:
                case MFG_BACK_ID:
                    main_page();
                    break;
                case MAIN_BOOT_ID:
                    running=FALSE;
                    break;
                case DEBUG_CDROM_BOOT_ID:
                    asave->cdrom_boot=gad->Flags&GFLG_SELECTED?TRUE:FALSE;
                    Save_BattMem();
                    break;
                case DEBUG_IGNORE_LAST_ID:
                    asave->ignore_last=gad->Flags&GFLG_SELECTED?TRUE:FALSE;
                    Save_BattMem();
                    break;
#ifdef ENABLE_QUICKINTS
                case DEBUG_QUICK_INT_ID:
                    asave->quick_int=gad->Flags&GFLG_SELECTED?TRUE:FALSE;
                    Save_BattMem();
                    break;
#endif
                case DEBUG_ALLOW_DISC_ID:
                    asave->allow_disc=gad->Flags&GFLG_SELECTED?TRUE:FALSE;
                    Save_BattMem();
                    break;
                }
            }
        }
    }
}

void boot_menu(void)
{
    printf("Bootmenu:\n");

    /* Check left mouse button.
     * (If the left mouse button is pressed, we do not enter the boot menu.)
     */

    if (!(REG_CIAAPRA_PA6 & *((volatile char *)REG_CIAAPRA))) {
        printf("LMB pressed.\n");
        return;
    }

    /* Open graphics.library for WaitTOF */
    GfxBase = (struct GfxBase *)OpenLibrary("graphics.library",0);
    IntuitionBase = OpenLibrary("intuition.library", 0);

    /*
     * Configure Paula POTGO LX + LY pins (Port 0 Button 2 + 3) as
     * output high. Paula implements a pull-up on the pins in this
     * mode, which may be overdriven (low) by a mouse button press.
     */
    *(volatile UWORD *)REG_POTGO = 0x0f00;

    /* Wait for Paula to refresh GPIO state */
    WaitTOF();
    WaitTOF();

    /*
     * Check if neither the right mouse button nor the DEL key is pressed.
     * - For the right mouse button, REG_POTGOR_DATLY is active low.
     * - For the DEL key, we read the CIAA SDR at 0xBFEC01. If no key is
     *   pressed or a key other than DEL is present, the value will not
     *   equal KEY_DEL_CODE.
     *
     * If both inputs are inactive (i.e. right mouse not pressed and DEL key
     * not pressed), then do not show the boot menu.
     */
    unsigned char key = (~(*(volatile unsigned char *)REG_CIAASDR)&0xff);
    key = (key >> 1) | (key << 7);
    if ((REG_POTGOR_DATLY & *(volatile UWORD *)REG_POTGOR) &&
        (key != KEY_DEL_CODE))
    {
        printf("Neither RMB nor DEL key pressed.\n");
        CloseLibrary((struct Library *)IntuitionBase);
        CloseLibrary((struct Library *)GfxBase);
        return;
    }

    // Hack!?
    InitResident(FindResident("gadtools.library"), 0);
    GadToolsBase  = OpenLibrary("gadtools.library",36);

    printf("Bootmenu: enter\n");

#if defined(FLASH_PARALLEL) || defined(FLASH_SPI) || defined(OEM_KICKMODULE)
    probe_oem_bundle();
#endif

    if (!init_bootmenu()) {
        cleanup_bootmenu();
        printf("Bootmenu: failed to open screen\n");
        return;
    }
    main_page();
    event_loop();
#if defined(FLASH_PARALLEL) || defined(FLASH_SPI)
    {
        int committed = Nvram_CommitDirty();
        if (committed > 0) {
            show_toast("Settings saved.");
        }
        if (committed < 0) {
            show_toast("Failure to save settings.");
	}
    }
#endif
    cleanup_bootmenu();
    printf("Bootmenu: exit\n");
    ColdReboot();
    return;
}
